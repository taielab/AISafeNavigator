# AI Safe Navigator 管理系统实现文档

## 一、项目结构

### 1. 目录结构
```
admin/
├── src/
│   ├── app/                    # Next.js 应用目录
│   │   ├── (auth)/            # 认证相关页面
│   │   │   ├── login/         # 登录页面
│   │   │   └── register/      # 注册页面
│   │   ├── (dashboard)/       # 仪表盘页面
│   │   │   ├── tools/         # 工具管理
│   │   │   ├── categories/    # 分类管理
│   │   │   └── stats/         # 数据统计
│   │   └── layout.tsx         # 主布局
│   ├── components/            # 组件目录
│   │   ├── ui/               # UI 组件
│   │   ├── forms/            # 表单组件
│   │   └── charts/           # 图表组件
│   ├── lib/                  # 工具函数
│   │   ├── auth/             # 认证相关
│   │   ├── api/              # API 调用
│   │   └── utils/            # 通用工具
│   └── types/                # 类型定义
└── package.json

server/
├── src/
│   ├── main.ts               # 应用入口
│   ├── app.module.ts         # 主模块
│   ├── auth/                 # 认证模块
│   │   ├── auth.module.ts
│   │   ├── auth.service.ts
│   │   ├── auth.controller.ts
│   │   └── strategies/       # 认证策略
│   ├── tools/                # 工具模块
│   ├── categories/           # 分类模块
│   ├── users/                # 用户模块
│   └── common/               # 公共模块
└── package.json
```

### 2. 技术栈配置

#### 2.1 前端配置
```typescript
// package.json
{
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.0.0",
    "antd": "^5.0.0",
    "@ant-design/pro-components": "^2.0.0",
    "@tanstack/react-query": "^4.0.0",
    "zustand": "^4.0.0",
    "axios": "^1.0.0",
    "jose": "^4.0.0",
    "zod": "^3.0.0"
  }
}

// next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverActions: true
  },
  async redirects() {
    return [
      {
        source: '/',
        destination: '/dashboard',
        permanent: true,
      },
    ]
  }
}
```

#### 2.2 后端配置
```typescript
// package.json
{
  "dependencies": {
    "@nestjs/common": "^10.0.0",
    "@nestjs/core": "^10.0.0",
    "@nestjs/jwt": "^10.0.0",
    "@nestjs/passport": "^10.0.0",
    "@prisma/client": "^5.0.0",
    "passport": "^0.6.0",
    "passport-jwt": "^4.0.0",
    "passport-local": "^1.0.0",
    "bcrypt": "^5.0.0"
  }
}
```

## 二、认证系统实现

### 1. 前端实现

#### 1.1 认证状态管理
```typescript
// src/lib/auth/store.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface AuthState {
  token: string | null
  user: User | null
  setAuth: (token: string, user: User) => void
  clearAuth: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      setAuth: (token, user) => set({ token, user }),
      clearAuth: () => set({ token: null, user: null }),
    }),
    {
      name: 'auth-storage',
    }
  )
)
```

#### 1.2 登录页面
```typescript
// src/app/(auth)/login/page.tsx
'use client'

import { useState } from 'react'
import { Form, Input, Button, message } from 'antd'
import { useAuthStore } from '@/lib/auth/store'
import { login } from '@/lib/api/auth'

export default function LoginPage() {
  const [loading, setLoading] = useState(false)
  const setAuth = useAuthStore((state) => state.setAuth)

  const onFinish = async (values: any) => {
    try {
      setLoading(true)
      const { token, user } = await login(values)
      setAuth(token, user)
      message.success('登录成功')
      router.push('/dashboard')
    } catch (error) {
      message.error('登录失败')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Form onFinish={onFinish}>
      <Form.Item
        name="email"
        rules={[
          { required: true, message: '请输入邮箱' },
          { type: 'email', message: '请输入有效的邮箱' }
        ]}
      >
        <Input placeholder="邮箱" />
      </Form.Item>
      <Form.Item
        name="password"
        rules={[{ required: true, message: '请输入密码' }]}
      >
        <Input.Password placeholder="密码" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" loading={loading}>
          登录
        </Button>
      </Form.Item>
    </Form>
  )
}
```

#### 1.3 认证中间件
```typescript
// src/middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyAuth } from '@/lib/auth/utils'

export async function middleware(request: NextRequest) {
  // 公开路由
  const publicPaths = ['/login', '/register']
  if (publicPaths.includes(request.nextUrl.pathname)) {
    return NextResponse.next()
  }

  // 验证 token
  const token = request.cookies.get('token')
  if (!token || !await verifyAuth(token)) {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}
```

### 2. 后端实现

#### 2.1 认证模块
```typescript
// src/auth/auth.module.ts
import { Module } from '@nestjs/common'
import { JwtModule } from '@nestjs/jwt'
import { PassportModule } from '@nestjs/passport'
import { AuthService } from './auth.service'
import { AuthController } from './auth.controller'
import { JwtStrategy } from './strategies/jwt.strategy'
import { LocalStrategy } from './strategies/local.strategy'

@Module({
  imports: [
    PassportModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '24h' },
    }),
  ],
  providers: [AuthService, LocalStrategy, JwtStrategy],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
```

#### 2.2 认证服务
```typescript
// src/auth/auth.service.ts
import { Injectable } from '@nestjs/common'
import { JwtService } from '@nestjs/jwt'
import { PrismaService } from '../prisma/prisma.service'
import { compare, hash } from 'bcrypt'

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, password: string): Promise<any> {
    const user = await this.prisma.user.findUnique({ where: { email } })
    if (user && await compare(password, user.password)) {
      const { password, ...result } = user
      return result
    }
    return null
  }

  async login(user: any) {
    const payload = { email: user.email, sub: user.id }
    return {
      token: this.jwtService.sign(payload),
      user,
    }
  }

  async register(email: string, password: string) {
    const hashedPassword = await hash(password, 10)
    const user = await this.prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        role: 'USER',
      },
    })
    const { password: _, ...result } = user
    return result
  }
}
```

#### 2.3 认证控制器
```typescript
// src/auth/auth.controller.ts
import { Controller, Post, Body, UseGuards } from '@nestjs/common'
import { AuthService } from './auth.service'
import { LocalAuthGuard } from './guards/local-auth.guard'

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @UseGuards(LocalAuthGuard)
  @Post('login')
  async login(@Body() loginDto: LoginDto) {
    return this.authService.login(loginDto)
  }

  @Post('register')
  async register(@Body() registerDto: RegisterDto) {
    return this.authService.register(
      registerDto.email,
      registerDto.password,
    )
  }
}
```

#### 2.4 认证策略
```typescript
// src/auth/strategies/jwt.strategy.ts
import { Injectable } from '@nestjs/common'
import { PassportStrategy } from '@nestjs/passport'
import { ExtractJwt, Strategy } from 'passport-jwt'

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET,
    })
  }

  async validate(payload: any) {
    return { id: payload.sub, email: payload.email }
  }
}

// src/auth/strategies/local.strategy.ts
import { Injectable, UnauthorizedException } from '@nestjs/common'
import { PassportStrategy } from '@nestjs/passport'
import { Strategy } from 'passport-local'
import { AuthService } from '../auth.service'

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private authService: AuthService) {
    super({ usernameField: 'email' })
  }

  async validate(email: string, password: string): Promise<any> {
    const user = await this.authService.validateUser(email, password)
    if (!user) {
      throw new UnauthorizedException()
    }
    return user
  }
}
```

### 3. 数据库设计

#### 3.1 Prisma Schema
```prisma
// prisma/schema.prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String
  role      String   @default("USER")
  status    String   @default("ACTIVE")
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Session {
  id        String   @id @default(uuid())
  userId    String
  token     String   @unique
  expiresAt DateTime
  createdAt DateTime @default(now())
  user      User     @relation(fields: [userId], references: [id])
}
```

### 4. API 接口

#### 4.1 认证接口
```typescript
// src/types/api.ts
export interface LoginRequest {
  email: string
  password: string
}

export interface LoginResponse {
  token: string
  user: {
    id: string
    email: string
    role: string
  }
}

export interface RegisterRequest {
  email: string
  password: string
}

export interface RegisterResponse {
  id: string
  email: string
  role: string
}
```

#### 4.2 接口实现
```typescript
// src/lib/api/auth.ts
import axios from 'axios'

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
})

export const login = async (data: LoginRequest): Promise<LoginResponse> => {
  const response = await api.post('/auth/login', data)
  return response.data
}

export const register = async (data: RegisterRequest): Promise<RegisterResponse> => {
  const response = await api.post('/auth/register', data)
  return response.data
}

export const logout = async () => {
  await api.post('/auth/logout')
}
```

## 三、开发计划

### 1. 第一周：基础架构
- [x] 项目初始化
- [x] 目录结构搭建
- [x] 基础组件开发
- [x] 路由配置

### 2. 第二周：认证系统
- [ ] 用户模型设计
- [ ] 登录功能实现
- [ ] 注册功能实现
- [ ] 权限控制

### 3. 第三周：核心功能
- [ ] 工具管理
- [ ] 分类管理
- [ ] 用户管理
- [ ] 基础统计

### 4. 第四周：优化和测试
- [ ] 性能优化
- [ ] 单元测试
- [ ] 集成测试
- [ ] 部署配置

## 四、数据统计实现

### 1. 数据模型设计

#### 1.1 访问统计
```prisma
// prisma/schema.prisma
model PageView {
  id        String   @id @default(uuid())
  path      String
  userId    String?
  ip        String
  userAgent String
  referer   String?
  duration  Int      // 访问时长（秒）
  createdAt DateTime @default(now())
}

model SearchLog {
  id        String   @id @default(uuid())
  keyword   String
  userId    String?
  results   Int      // 搜索结果数
  createdAt DateTime @default(now())
}

model ToolVisit {
  id        String   @id @default(uuid())
  toolId    String
  userId    String?
  action    String   // VIEW, CLICK, FAVORITE
  createdAt DateTime @default(now())
}
```

### 2. 后端实现

#### 2.1 统计服务
```typescript
// src/stats/stats.service.ts
import { Injectable } from '@nestjs/common'
import { PrismaService } from '../prisma/prisma.service'

@Injectable()
export class StatsService {
  constructor(private prisma: PrismaService) {}

  // 获取总览数据
  async getOverview(): Promise<Overview> {
    const [
      totalPageViews,
      totalUsers,
      totalTools,
      totalSearches
    ] = await Promise.all([
      this.prisma.pageView.count(),
      this.prisma.user.count(),
      this.prisma.tool.count(),
      this.prisma.searchLog.count()
    ])

    return {
      totalPageViews,
      totalUsers,
      totalTools,
      totalSearches
    }
  }

  // 获取访问趋势
  async getVisitTrends(days: number): Promise<VisitTrend[]> {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    return this.prisma.pageView.groupBy({
      by: ['createdAt'],
      _count: true,
      where: {
        createdAt: {
          gte: startDate
        }
      },
      orderBy: {
        createdAt: 'asc'
      }
    })
  }

  // 获取热门搜索
  async getTopSearches(limit: number): Promise<TopSearch[]> {
    return this.prisma.searchLog.groupBy({
      by: ['keyword'],
      _count: true,
      orderBy: {
        _count: {
          keyword: 'desc'
        }
      },
      take: limit
    })
  }

  // 获取工具访问排行
  async getTopTools(limit: number): Promise<TopTool[]> {
    return this.prisma.toolVisit.groupBy({
      by: ['toolId'],
      _count: true,
      orderBy: {
        _count: {
          toolId: 'desc'
        }
      },
      take: limit
    })
  }
}
```

#### 2.2 统计控制器
```typescript
// src/stats/stats.controller.ts
import { Controller, Get, Query } from '@nestjs/common'
import { StatsService } from './stats.service'

@Controller('stats')
export class StatsController {
  constructor(private statsService: StatsService) {}

  @Get('overview')
  async getOverview() {
    return this.statsService.getOverview()
  }

  @Get('trends')
  async getVisitTrends(@Query('days') days: number = 7) {
    return this.statsService.getVisitTrends(days)
  }

  @Get('searches')
  async getTopSearches(@Query('limit') limit: number = 10) {
    return this.statsService.getTopSearches(limit)
  }

  @Get('tools')
  async getTopTools(@Query('limit') limit: number = 10) {
    return this.statsService.getTopTools(limit)
  }
}
```

### 3. 前端实现

#### 3.1 统计 API 调用
```typescript
// src/lib/api/stats.ts
import { api } from './base'

export const getOverview = async (): Promise<Overview> => {
  const response = await api.get('/stats/overview')
  return response.data
}

export const getVisitTrends = async (days: number = 7): Promise<VisitTrend[]> => {
  const response = await api.get('/stats/trends', { params: { days } })
  return response.data
}

export const getTopSearches = async (limit: number = 10): Promise<TopSearch[]> => {
  const response = await api.get('/stats/searches', { params: { limit } })
  return response.data
}

export const getTopTools = async (limit: number = 10): Promise<TopTool[]> => {
  const response = await api.get('/stats/tools', { params: { limit } })
  return response.data
}
```

#### 3.2 统计页面组件
```typescript
// src/app/(dashboard)/stats/page.tsx
'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, Row, Col, Statistic, Table } from 'antd'
import {
  LineChart,
  BarChart,
  PieChart
} from '@/components/charts'
import {
  getOverview,
  getVisitTrends,
  getTopSearches,
  getTopTools
} from '@/lib/api/stats'

export default function StatsPage() {
  // 获取总览数据
  const { data: overview } = useQuery({
    queryKey: ['stats', 'overview'],
    queryFn: getOverview
  })

  // 获取访问趋势
  const { data: trends } = useQuery({
    queryKey: ['stats', 'trends'],
    queryFn: () => getVisitTrends(7)
  })

  // 获取热门搜索
  const { data: searches } = useQuery({
    queryKey: ['stats', 'searches'],
    queryFn: () => getTopSearches(10)
  })

  // 获取工具排行
  const { data: tools } = useQuery({
    queryKey: ['stats', 'tools'],
    queryFn: () => getTopTools(10)
  })

  return (
    <div className="p-6">
      {/* 总览卡片 */}
      <Row gutter={16} className="mb-6">
        <Col span={6}>
          <Card>
            <Statistic
              title="总访问量"
              value={overview?.totalPageViews}
              loading={!overview}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="用户数"
              value={overview?.totalUsers}
              loading={!overview}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="工具数"
              value={overview?.totalTools}
              loading={!overview}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="搜索次数"
              value={overview?.totalSearches}
              loading={!overview}
            />
          </Card>
        </Col>
      </Row>

      {/* 访问趋势图 */}
      <Card title="访问趋势" className="mb-6">
        <LineChart
          data={trends || []}
          loading={!trends}
          xField="createdAt"
          yField="_count"
        />
      </Card>

      {/* 热门搜索和工具排行 */}
      <Row gutter={16}>
        <Col span={12}>
          <Card title="热门搜索">
            <Table
              dataSource={searches}
              columns={[
                {
                  title: '关键词',
                  dataIndex: 'keyword',
                },
                {
                  title: '搜索次数',
                  dataIndex: '_count',
                },
              ]}
              loading={!searches}
              pagination={false}
            />
          </Card>
        </Col>
        <Col span={12}>
          <Card title="工具访问排行">
            <Table
              dataSource={tools}
              columns={[
                {
                  title: '工具',
                  dataIndex: 'toolId',
                },
                {
                  title: '访问次数',
                  dataIndex: '_count',
                },
              ]}
              loading={!tools}
              pagination={false}
            />
          </Card>
        </Col>
      </Row>
    </div>
  )
}
```

#### 3.3 图表组件
```typescript
// src/components/charts/LineChart.tsx
import { Line } from '@ant-design/charts'

interface LineChartProps {
  data: any[]
  loading?: boolean
  xField: string
  yField: string
}

export function LineChart({
  data,
  loading,
  xField,
  yField
}: LineChartProps) {
  const config = {
    data,
    xField,
    yField,
    point: {
      size: 4,
      shape: 'circle',
    },
    tooltip: {
      showMarkers: false,
    },
    state: {
      active: {
        style: {
          shadowBlur: 4,
          stroke: '#000',
          fill: 'red',
        },
      },
    },
    interactions: [
      {
        type: 'marker-active',
      },
    ],
  }

  return <Line {...config} loading={loading} />
}
```

### 4. 数据收集

#### 4.1 访问统计中间件
```typescript
// src/common/middleware/stats.middleware.ts
import { Injectable, NestMiddleware } from '@nestjs/common'
import { Request, Response, NextFunction } from 'express'
import { StatsService } from '../../stats/stats.service'

@Injectable()
export class StatsMiddleware implements NestMiddleware {
  constructor(private statsService: StatsService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    // 记录访问开始时间
    const startTime = Date.now()

    // 响应结束时记录访问数据
    res.on('finish', () => {
      const duration = Date.now() - startTime
      this.statsService.recordPageView({
        path: req.path,
        userId: req.user?.id,
        ip: req.ip,
        userAgent: req.headers['user-agent'] || '',
        referer: req.headers.referer,
        duration: Math.floor(duration / 1000),
      })
    })

    next()
  }
}
```

#### 4.2 搜索记录
```typescript
// src/tools/tools.service.ts
@Injectable()
export class ToolsService {
  constructor(
    private prisma: PrismaService,
    private statsService: StatsService,
  ) {}

  async search(keyword: string, userId?: string) {
    const results = await this.prisma.tool.findMany({
      where: {
        OR: [
          { name: { contains: keyword } },
          { description: { contains: keyword } },
        ],
      },
    })

    // 记录搜索日志
    await this.statsService.recordSearch({
      keyword,
      userId,
      results: results.length,
    })

    return results
  }
}
```

#### 4.3 工具访问记录
```typescript
// src/tools/tools.service.ts
async recordToolVisit(toolId: string, userId: string | null, action: string) {
  await this.prisma.toolVisit.create({
    data: {
      toolId,
      userId,
      action,
    },
  })
}
```

### 5. 数据导出

#### 5.1 导出服务
```typescript
// src/stats/stats.service.ts
async exportData(type: string, startDate: Date, endDate: Date): Promise<Buffer> {
  let data: any[] = []

  switch (type) {
    case 'pageviews':
      data = await this.prisma.pageView.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lte: endDate,
          },
        },
      })
      break
    case 'searches':
      data = await this.prisma.searchLog.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lte: endDate,
          },
        },
      })
      break
    // ... 其他类型
  }

  // 转换为 CSV
  const csv = await this.convertToCSV(data)
  return Buffer.from(csv)
}
```

#### 5.2 导出控制器
```typescript
// src/stats/stats.controller.ts
@Get('export')
async exportData(
  @Query('type') type: string,
  @Query('startDate') startDate: string,
  @Query('endDate') endDate: string,
  @Res() res: Response,
) {
  const data = await this.statsService.exportData(
    type,
    new Date(startDate),
    new Date(endDate),
  )

  res.setHeader('Content-Type', 'text/csv')
  res.setHeader(
    'Content-Disposition',
    `attachment; filename=stats-${type}-${startDate}-${endDate}.csv`
  )
  res.send(data)
}
```

### 6. 监控告警

#### 6.1 告警规则
```typescript
// src/stats/alert.service.ts
@Injectable()
export class AlertService {
  // 检查异常访问
  async checkAbnormalVisits() {
    const threshold = 1000 // 每分钟访问阈值
    const visits = await this.prisma.pageView.count({
      where: {
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000), // 最近一分钟
        },
      },
    })

    if (visits > threshold) {
      await this.sendAlert('访问量异常', `当前访问量: ${visits}/分钟`)
    }
  }

  // 检查错误率
  async checkErrorRate() {
    const threshold = 0.05 // 5% 错误率阈值
    const [total, errors] = await Promise.all([
      this.prisma.pageView.count(),
      this.prisma.pageView.count({
        where: {
          status: 500,
        },
      }),
    ])

    const errorRate = errors / total
    if (errorRate > threshold) {
      await this.sendAlert('错误率过高', `当前错误率: ${errorRate * 100}%`)
    }
  }

  private async sendAlert(title: string, message: string) {
    // 发送告警通知（邮件、钉钉等）
  }
}
```

### 7. 缓存策略

#### 7.1 Redis 缓存
```typescript
// src/stats/stats.service.ts
@Injectable()
export class StatsService {
  constructor(
    private prisma: PrismaService,
    private redis: Redis,
  ) {}

  async getOverview(): Promise<Overview> {
    // 尝试从缓存获取
    const cached = await this.redis.get('stats:overview')
    if (cached) {
      return JSON.parse(cached)
    }

    // 从数据库获取
    const data = await this._getOverviewFromDB()

    // 写入缓存
    await this.redis.set(
      'stats:overview',
      JSON.stringify(data),
      'EX',
      300 // 5分钟过期
    )

    return data
  }
}
```

#### 7.2 定时更新
```typescript
// src/stats/stats.service.ts
@Cron('*/5 * * * *') // 每5分钟
async updateCache() {
  const data = await this._getOverviewFromDB()
  await this.redis.set(
    'stats:overview',
    JSON.stringify(data),
    'EX',
    300
  )
}
```

### 8. 性能优化

#### 8.1 数据库索引
```sql
-- 为常用查询添加索引
CREATE INDEX idx_pageview_created_at ON page_views(created_at);
CREATE INDEX idx_search_keyword ON search_logs(keyword);
CREATE INDEX idx_tool_visit_tool_id ON tool_visits(tool_id);
```

#### 8.2 数据聚合
```typescript
// src/stats/stats.service.ts
@Injectable()
export class StatsService {
  @Cron('0 0 * * *') // 每天凌晨
  async aggregateData() {
    // 聚合前一天的数据
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)

    await this.prisma.dailyStats.create({
      data: {
        date: yesterday,
        pageViews: await this._countPageViews(yesterday),
        uniqueUsers: await this._countUniqueUsers(yesterday),
        // ... 其他统计数据
      },
    })
  }
}
```