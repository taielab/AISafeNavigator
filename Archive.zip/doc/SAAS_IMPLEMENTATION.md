# AI Safe Navigator SaaS 瀹炵幇鏂规

## 涓€銆佹妧鏈爤璋冩暣

### 1. SaaS 鏈嶅姟閫夊瀷
- 鍐呭绠＄悊锛歋anity.io
- 鐢ㄦ埛璁よ瘉锛欳lerk.com
- 鏁版嵁搴擄細浠嶄娇鐢� Supabase锛堢敤浜庡瓨鍌ㄩ澶栨暟鎹級
- 閮ㄧ讲锛歏ercel

### 2. 渚濊禆閰嶇疆
```json
{
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.0.0",
    "@sanity/client": "^6.0.0",
    "@clerk/nextjs": "^4.0.0",
    "@supabase/supabase-js": "^2.0.0",
    "tailwindcss": "^3.0.0",
    "@ant-design/charts": "^1.0.0"
  }
}
```

## 浜屻€丼anity 鍐呭绠＄悊

### 1. Schema 璁捐
```typescript
// sanity/schemas/tool.ts
export default {
  name: 'tool',
  title: 'AI Tool',
  type: 'document',
  fields: [
    {
      name: 'name',
      title: 'Name',
      type: 'string',
      validation: Rule => Rule.required()
    },
    {
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'name',
        maxLength: 96
      }
    },
    {
      name: 'description',
      title: 'Description',
      type: 'text'
    },
    {
      name: 'category',
      title: 'Category',
      type: 'reference',
      to: [{type: 'category'}]
    },
    {
      name: 'tags',
      title: 'Tags',
      type: 'array',
      of: [{type: 'string'}]
    },
    {
      name: 'url',
      title: 'URL',
      type: 'url'
    },
    {
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {
        hotspot: true
      }
    },
    {
      name: 'status',
      title: 'Status',
      type: 'string',
      options: {
        list: [
          {title: 'Draft', value: 'draft'},
          {title: 'Published', value: 'published'},
          {title: 'Archived', value: 'archived'}
        ]
      }
    }
  ]
}
```

### 2. Sanity 瀹㈡埛绔厤缃�
```typescript
// lib/sanity.ts
import { createClient } from '@sanity/client'

export const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET,
  useCdn: process.env.NODE_ENV === 'production',
  apiVersion: '2023-12-01',
  token: process.env.SANITY_API_TOKEN
})

// 鏌ヨ宸ュ叿
export async function getTools(query: string = '*') {
  return client.fetch(`
    *[_type == "tool" && status == "published" ${query}] {
      _id,
      name,
      description,
      url,
      "category": category->name,
      tags,
      "image": image.asset->url
    }
  `)
}

// 鑾峰彇鍒嗙被
export async function getCategories() {
  return client.fetch(`
    *[_type == "category"] {
      _id,
      name,
      description,
      "toolCount": count(*[_type == "tool" && references(^._id)])
    }
  `)
}
```

## 涓夈€丆lerk 鐢ㄦ埛璁よ瘉

### 1. Clerk 閰嶇疆
```typescript
// app/layout.tsx
import { ClerkProvider } from '@clerk/nextjs'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>{children}</body>
      </html>
    </ClerkProvider>
  )
}
```

### 2. 璁よ瘉涓棿浠�
```typescript
// middleware.ts
import { authMiddleware } from "@clerk/nextjs"

export default authMiddleware({
  publicRoutes: ["/", "/tool/:path*", "/category/:path*"],
  ignoredRoutes: ["/api/webhook/clerk"]
})

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
}
```

### 3. 鐢ㄦ埛缁勪欢
```typescript
// components/UserButton.tsx
import { UserButton, SignInButton } from "@clerk/nextjs"
import { useUser } from "@clerk/nextjs"

export function AuthButton() {
  const { isSignedIn } = useUser()
  
  return isSignedIn ? (
    <UserButton afterSignOutUrl="/" />
  ) : (
    <SignInButton mode="modal" />
  )
}
```

## 鍥涖€佹暟锟斤拷锟界粺璁″疄鐜�

### 1. Supabase 琛ㄨ璁�
```sql
-- 璁块棶缁熻
create table page_views (
  id uuid default uuid_generate_v4() primary key,
  path text not null,
  user_id text references auth.users,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 鎼滅储璁板綍
create table search_logs (
  id uuid default uuid_generate_v4() primary key,
  keyword text not null,
  user_id text references auth.users,
  results_count integer not null,
  created_at timestamp with time zone default timezone('utc'::text, now())
);
```

### 2. 缁熻 API
```typescript
// app/api/stats/route.ts
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export async function GET() {
  const supabase = createRouteHandlerClient({ cookies })
  
  const [pageViews, searches] = await Promise.all([
    supabase.from('page_views').select('count'),
    supabase.from('search_logs').select('count')
  ])
  
  return Response.json({
    pageViews: pageViews.count,
    searches: searches.count
  })
}
```

### 3. 缁熻缁勪欢
```typescript
// components/Stats.tsx
'use client'

import { Card, Row, Col, Statistic } from 'antd'
import { useQuery } from '@tanstack/react-query'

export function Stats() {
  const { data, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => fetch('/api/stats').then(res => res.json())
  })
  
  return (
    <Row gutter={16}>
      <Col span={12}>
        <Card>
          <Statistic
            title="椤甸潰璁块棶"
            value={data?.pageViews}
            loading={isLoading}
          />
        </Card>
      </Col>
      <Col span={12}>
        <Card>
          <Statistic
            title="鎼滅储娆℃暟"
            value={data?.searches}
            loading={isLoading}
          />
        </Card>
      </Col>
    </Row>
  )
}
```

## 浜斻€侀儴缃查厤缃�

### 1. 鐜鍙橀噺
```env
# Sanity
NEXT_PUBLIC_SANITY_PROJECT_ID=
NEXT_PUBLIC_SANITY_DATASET=
SANITY_API_TOKEN=

# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=
CLERK_SECRET_KEY=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

### 2. Vercel 閰嶇疆
```json
{
  "buildCommand": "npm run build",
  "devCommand": "npm run dev",
  "installCommand": "npm install",
  "framework": "nextjs",
  "outputDirectory": ".next"
}
```

## 鍏€佸紑鍙戣鍒�

### 绗竴鍛細鍩虹璁剧疆
- [ ] Sanity 椤圭洰璁剧疆
- [ ] Schema 璁捐
- [ ] Clerk 闆嗘垚
- [ ] 鍩虹椤甸潰寮€鍙�

### 绗簩鍛細鍐呭绠＄悊
- [ ] 宸ュ叿绠＄悊鐣岄潰
- [ ] 鍒嗙被绠＄悊
- [ ] 鍐呭缂栬緫娴佺▼
- [ ] 鍥剧墖澶勭悊

### 绗笁鍛細鐢ㄦ埛鍔熻兘
- [ ] 鐢ㄦ埛璁よ瘉娴佺▼
- [ ] 鏉冮檺鎺у埗
- [ ] 涓汉涓績
- [ ] 鏀惰棌鍔熻兘

### 绗洓鍛細缁熻鍜屼紭鍖�
- [ ] 璁块棶缁熻
- [ ] 鎼滅储鍒嗘瀽
- [ ] 鎬ц兘浼樺寲
- [ ] SEO 浼樺寲

## 涓冦€佹敞鎰忎簨椤�

### 1. 鏁版嵁瀹夊叏
- Sanity 鐨� API Token 鏉冮檺鎺у埗
- Clerk 鐨勭敤鎴锋暟鎹繚鎶�
- Supabase 鐨勬暟鎹闂帶鍒�

### 2. 鎬ц兘浼樺寲
- Sanity 鐨� GROQ 鏌ヨ浼樺寲
- Next.js 鐨勯潤鎬佺敓鎴愬拰澧為噺闈欐€佸啀鐢熸垚
- 鍥剧墖浼樺寲鍜� CDN 浣跨敤

### 3. 鎴愭湰鎺у埗
- Sanity 鐨� API 璋冪敤闄愬埗
- Clerk 鐨勭敤鎴锋暟閲忚璐�
- Supabase 鐨勬暟鎹瓨鍌ㄥ拰甯﹀浣跨敤

### 4. 澶囦唤绛栫暐
- Sanity 鍐呭鐨勫畾鏈熷鍑�
- Supabase 鏁版嵁鐨勫浠借鍒�
- 閰嶇疆鏂囦欢鐨勭増鏈帶鍒�

## 鍏€佽嚜鍔ㄦ洿鏂版敹褰曠郴缁�

### 1. 鏁版嵁婧愰泦鎴�

#### 1.1 API 闆嗘垚
```typescript
// lib/sources/index.ts
interface ToolSource {
  name: string;
  type: 'api' | 'rss' | 'scrape';
  enabled: boolean;
  config: {
    url: string;
    apiKey?: string;
    interval: number; // 鏇存柊闂撮殧锛堝垎閽燂級
  };
}

const sources: ToolSource[] = [
  {
    name: 'ProductHunt',
    type: 'api',
    enabled: true,
    config: {
      url: 'https://api.producthunt.com/v2/api/graphql',
      apiKey: process.env.PRODUCTHUNT_API_KEY,
      interval: 60 // 姣忓皬鏃舵洿鏂�
    }
  },
  {
    name: 'GitHub',
    type: 'api',
    enabled: true,
    config: {
      url: 'https://api.github.com/search/repositories',
      apiKey: process.env.GITHUB_API_TOKEN,
      interval: 120 // 姣�2灏忔椂鏇存柊
    }
  }
]
```

#### 1.2 鐖櫕閰嶇疆
```typescript
// lib/crawler/config.ts
interface CrawlerConfig {
  name: string;
  url: string;
  selectors: {
    title: string;
    description: string;
    link: string;
    image?: string;
  };
  interval: number;
}

const crawlerConfigs: CrawlerConfig[] = [
  {
    name: 'AITools',
    url: 'https://example.com/ai-tools',
    selectors: {
      title: '.tool-title',
      description: '.tool-description',
      link: '.tool-link',
      image: '.tool-image'
    },
    interval: 1440 // 姣忓ぉ鏇存柊
  }
]
```

### 2. 鏁版嵁閲囬泦瀹炵幇

#### 2.1 API 閲囬泦鍣�
```typescript
// lib/collectors/api-collector.ts
import axios from 'axios'
import { client } from '../sanity'

export class APICollector {
  constructor(private source: ToolSource) {}

  async collect() {
    try {
      const response = await axios.get(this.source.config.url, {
        headers: this.source.config.apiKey ? {
          Authorization: `Bearer ${this.source.config.apiKey}`
        } : {}
      })

      const tools = this.transformData(response.data)
      await this.saveToDB(tools)
    } catch (error) {
      console.error(`Error collecting from ${this.source.name}:`, error)
    }
  }

  private transformData(data: any): Tool[] {
    // 鏍规嵁涓嶅悓鏁版嵁婧愯浆鎹㈡暟鎹牸寮�
    switch (this.source.name) {
      case 'ProductHunt':
        return data.posts.map(post => ({
          name: post.name,
          description: post.tagline,
          url: post.url,
          // ... 鍏朵粬瀛楁鏄犲皠
        }))
      // ... 鍏朵粬鏁版嵁婧愮殑杞崲
    }
  }

  private async saveToDB(tools: Tool[]) {
    const transaction = tools.map(tool => ({
      createIfNotExists: {
        _type: 'tool',
        name: tool.name,
        // 浣跨敤 URL 浣滀负鍞竴鏍囪瘑
        _id: `tool-${Buffer.from(tool.url).toString('base64')}`,
        // ... 鍏朵粬瀛楁
      },
      patch: {
        query: `*[_type == "tool" && url == "${tool.url}"][0]`,
        set: {
          description: tool.description,
          updatedAt: new Date().toISOString()
        }
      }
    }))

    await client.transaction(transaction).commit()
  }
}
```

#### 2.2 鐖櫕瀹炵幇
```typescript
// lib/collectors/crawler.ts
import puppeteer from 'puppeteer'
import { client } from '../sanity'

export class Crawler {
  constructor(private config: CrawlerConfig) {}

  async crawl() {
    const browser = await puppeteer.launch({
      headless: 'new'
    })

    try {
      const page = await browser.newPage()
      await page.goto(this.config.url)

      const tools = await page.evaluate((selectors) => {
        const items = document.querySelectorAll('.tool-item')
        return Array.from(items).map(item => ({
          title: item.querySelector(selectors.title)?.textContent,
          description: item.querySelector(selectors.description)?.textContent,
          link: item.querySelector(selectors.link)?.getAttribute('href'),
          image: item.querySelector(selectors.image)?.getAttribute('src')
        }))
      }, this.config.selectors)

      await this.saveToDB(tools)
    } finally {
      await browser.close()
    }
  }

  private async saveToDB(tools: any[]) {
    // 绫讳技 API 閲囬泦鍣ㄧ殑淇濆瓨閫昏緫
  }
}
```

### 3. 璋冨害绯荤粺

#### 3.1 浠诲姟璋冨害鍣�
```typescript
// lib/scheduler/index.ts
import { Cron } from '@nestjs/schedule'
import { APICollector } from '../collectors/api-collector'
import { Crawler } from '../collectors/crawler'
import { sources, crawlerConfigs } from '../config'

export class UpdateScheduler {
  @Cron('*/10 * * * *') // 姣�10鍒嗛挓妫€鏌ヤ竴娆�
  async checkUpdates() {
    const now = Date.now()

    // 妫€鏌� API 婧�
    for (const source of sources) {
      if (!source.enabled) continue
      
      const lastRun = await this.getLastRunTime(source.name)
      if (now - lastRun >= source.config.interval * 60 * 1000) {
        const collector = new APICollector(source)
        await collector.collect()
        await this.updateLastRunTime(source.name)
      }
    }

    // 妫€鏌ョ埇铏换鍔�
    for (const config of crawlerConfigs) {
      const lastRun = await this.getLastRunTime(config.name)
      if (now - lastRun >= config.interval * 60 * 1000) {
        const crawler = new Crawler(config)
        await crawler.crawl()
        await this.updateLastRunTime(config.name)
      }
    }
  }
}
```

#### 3.2 浠诲姟鐩戞帶
```typescript
// lib/scheduler/monitor.ts
interface TaskStatus {
  source: string;
  lastRun: Date;
  nextRun: Date;
  status: 'success' | 'failed';
  error?: string;
  stats: {
    total: number;
    new: number;
    updated: number;
  };
}

export class TaskMonitor {
  async getStatus(): Promise<TaskStatus[]> {
    // 浠庢暟鎹簱鑾峰彇浠诲姟鐘舵€�
    return []
  }

  async logTask(status: TaskStatus) {
    // 璁板綍浠诲姟鎵ц鐘舵€�
  }

  async alertOnFailure(status: TaskStatus) {
    // 浠诲姟澶辫触鍛婅
  }
}
```

### 4. 鏁版嵁澶勭悊

#### 4.1 鏁版嵁娓呮礂
```typescript
// lib/processors/cleaner.ts
export class DataCleaner {
  clean(tool: any) {
    return {
      ...tool,
      name: this.cleanText(tool.name),
      description: this.cleanText(tool.description),
      url: this.normalizeUrl(tool.url),
      // 绉婚櫎 HTML 鏍囩
      description: tool.description.replace(/<[^>]*>/g, ''),
      // 鏍囧噯鍖栨爣绛�
      tags: this.normalizeTags(tool.tags)
    }
  }

  private cleanText(text: string) {
    return text
      .trim()
      .replace(/\s+/g, ' ')
  }

  private normalizeUrl(url: string) {
    try {
      return new URL(url).toString()
    } catch {
      return null
    }
  }

  private normalizeTags(tags: string[]) {
    return tags
      .map(tag => tag.toLowerCase().trim())
      .filter(Boolean)
      .filter((tag, index, self) => self.indexOf(tag) === index)
  }
}
```

#### 4.2 閲嶅妫€娴�
```typescript
// lib/processors/duplicate-detector.ts
export class DuplicateDetector {
  async checkDuplicate(tool: any) {
    // 妫€鏌� URL 閲嶅
    const urlDuplicate = await this.checkUrlDuplicate(tool.url)
    if (urlDuplicate) return true

    // 妫€鏌ュ悕绉扮浉浼煎害
    const nameDuplicate = await this.checkNameSimilarity(tool.name)
    if (nameDuplicate) return true

    // 妫€鏌ユ弿杩扮浉浼煎害
    const descriptionDuplicate = await this.checkDescriptionSimilarity(tool.description)
    if (descriptionDuplicate) return true

    return false
  }

  private async checkNameSimilarity(name: string) {
    // 浣跨敤妯＄硦鍖归厤妫€鏌ュ悕绉扮浉浼煎害
    return false
  }

  private async checkDescriptionSimilarity(description: string) {
    // 浣跨敤鏂囨湰鐩镐技搴︾畻娉曟鏌ユ弿杩扮浉浼煎害
    return false
  }
}
```

### 5. 绠＄悊鐣岄潰

#### 5.1 鏁版嵁婧愮鐞�
```typescript
// app/(dashboard)/sources/page.tsx
'use client'

import { Table, Switch, Button, Space } from 'antd'
import { useQuery, useMutation } from '@tanstack/react-query'

export default function SourcesPage() {
  const { data: sources } = useQuery({
    queryKey: ['sources'],
    queryFn: () => fetch('/api/sources').then(res => res.json())
  })

  const columns = [
    {
      title: '鏁版嵁婧�',
      dataIndex: 'name',
    },
    {
      title: '绫诲瀷',
      dataIndex: 'type',
    },
    {
      title: '鐘舵€�',
      dataIndex: 'enabled',
      render: (enabled: boolean) => (
        <Switch checked={enabled} />
      ),
    },
    {
      title: '涓婃鏇存柊',
      dataIndex: 'lastRun',
    },
    {
      title: '鎿嶄綔',
      render: (source: any) => (
        <Space>
          <Button>缂栬緫</Button>
          <Button>绔嬪嵆鏇存柊</Button>
        </Space>
      ),
    },
  ]

  return (
    <div className="p-6">
      <Table
        columns={columns}
        dataSource={sources}
      />
    </div>
  )
}
```

#### 5.2 鏇存柊鏃ュ織
```typescript
// app/(dashboard)/update-logs/page.tsx
'use client'

import { Table, Tag } from 'antd'
import { useQuery } from '@tanstack/react-query'

export default function UpdateLogsPage() {
  const { data: logs } = useQuery({
    queryKey: ['update-logs'],
    queryFn: () => fetch('/api/update-logs').then(res => res.json())
  })

  const columns = [
    {
      title: '鏃堕棿',
      dataIndex: 'createdAt',
    },
    {
      title: '鏁版嵁婧�',
      dataIndex: 'source',
    },
    {
      title: '鐘舵€�',
      dataIndex: 'status',
      render: (status: string) => (
        <Tag color={status === 'success' ? 'green' : 'red'}>
          {status}
        </Tag>
      ),
    },
    {
      title: '鏂板',
      dataIndex: ['stats', 'new'],
    },
    {
      title: '鏇存柊',
      dataIndex: ['stats', 'updated'],
    },
  ]

  return (
    <div className="p-6">
      <Table
        columns={columns}
        dataSource={logs}
      />
    </div>
  )
}
```

### 6. 閰嶇疆璇存槑

#### 6.1 鐜鍙橀噺
```env
# API Keys
PRODUCTHUNT_API_KEY=
GITHUB_API_TOKEN=

# Crawler Settings
PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
CHROME_PATH=/usr/bin/google-chrome

# Update Settings
UPDATE_CHECK_INTERVAL=10 # 鍒嗛挓
MAX_CONCURRENT_TASKS=3
```

#### 6.2 鏇存柊瑙勫垯
1. 棰戠巼闄愬埗
   - API 婧愶細鏈€灏忛棿闅� 10 鍒嗛挓
   - 鐖櫕锛氭渶灏忛棿闅� 30 鍒嗛挓
   - 姣忎釜婧愭瘡澶╂渶澶氭洿鏂� 24 娆�

2. 鍐呭瑙勫垯
   - 鏍囬闀垮害锛�10-100 瀛楃
   - 鎻忚堪闀垮害锛�50-1000 瀛楃
   - 蹇呴』鍖呭惈鏈夋晥鐨� URL
   - 鍥剧墖蹇呴』鍙闂�

3. 鍘婚噸瑙勫垯
   - URL 瀹屽叏鍖归厤
   - 鏍囬鐩镐技搴� > 90%
   - 鎻忚堪鐩镐技搴� > 80%

### 7. 娉ㄦ剰浜嬮」

#### 7.1 鎬ц兘鑰冭檻
- 浣跨敤闃熷垪澶勭悊鏇存柊浠诲姟
- 瀹炵幇澧為噺鏇存柊
- 鍚堢悊璁剧疆骞跺彂鏁�
- 缂撳瓨閲嶅妫€娴嬬粨鏋�

#### 7.2 绋冲畾鎬т繚闅�
- 瀹炵幇浠诲姟閲嶈瘯鏈哄埗
- 璁剧疆瓒呮椂鎺у埗
- 璁板綍璇︾粏鏃ュ織
- 寮傚父鍛婅閫氱煡

#### 7.3 鏁版嵁璐ㄩ噺
- 瀹炵幇鏁版嵁楠岃瘉
- 璁剧疆璐ㄩ噺璇勫垎
- 浜哄伐瀹℃牳鏈哄埗
- 鑷姩绾犻敊鑳藉姏

#### 7.4 鍚堣鎬�
- 閬靛畧鐩爣缃戠珯瑙勫垯
- 鎺у埗璇锋眰棰戠巼
- 淇濆瓨鏁版嵁鏉ユ簮
- 娉ㄦ剰鐗堟潈闂
``` 
</rewritten_file>