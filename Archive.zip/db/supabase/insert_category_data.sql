INSERT INTO navigation_category(name, title, sort, del_flag, create_by, create_time) 
VALUES 
('image', 'Image', 0, 0, null, now());