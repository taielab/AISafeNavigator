INSERT INTO public.web_navigation (
    name, 
    title, 
    content, 
    detail, 
    url, 
    image_url, 
    thumbnail_url, 
    collection_time, 
    tag_name, 
    website_data, 
    star_rating, 
    category_name
) VALUES (
    '123rf-com',
    'Stock Photos, Vectors and Royalty Free Images from 123RF',
    'Search and download from millions of HD stock photos, royalty free images, cliparts, vectors and illustrations',
    E'### What is 123RF?\n\n123RF is a platform that provides access to a vast array of stock photos, vectors, and royalty-free images for various needs.\n\n### How can I use 123RF for free?\n\nEvery user can utilize 123RF\'s free images and vectors up to a certain limit. Subscribing to the platform grants additional benefits and extended access beyond the free usage limits.\n\n### Can I generate images using 123RF?\n\nYes, with 123RF\'s AI Image Generator, users can create images, sharing credits with other AI tools for a seamless creative experience.\n\n### How many AI tools are available on 123RF?\n\n123RF offers a wide range of AI tools, including AI Image Upscaler, AI Generative Fill, AI Background Blur, AI Background Remix, AI Image Extender, AI Writer, and AI Background Remover, for various applications in work, study, and everyday life.\n\n### How can I maximize my use of 123RF\'s AI services?\n\nBy leveraging the daily free uses of AI Image Generator, AI Image Upscaler, and other AI tools, users can explore a vast range of AI-powered tools to support various tasks.\n\n### Will my information be used for training data?\n\nWe highly value user privacy, and your data will not be used for any training purposes. If needed, you can delete your account at any time, and all your data will be removed as well.\n\n### When would I need a 123RF subscription?\n\nIf the free usage limits do not meet your needs and you heavily rely on 123RF\'s AI tools, we invite you to subscribe to our affordable products.',
    'https://www.123rf.com/',
    'https://img.tap4.ai/tools/2024/6/12/123rf-com-1718212803.png',
    'https://img.tap4.ai/tools/2024/6/12/123rf-com-thumbnail-1718212807.png',
    '2024-06-08 02:30:09',
    NULL,
    NULL,
    0,
    'image'
);
